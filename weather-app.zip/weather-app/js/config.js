// 高德地图API配置
// 请填写你的高德地图Web服务API Key
// 申请地址: https://lbs.amap.com/
const CONFIG = {
    // 高德地图API Key
    apiKey: '441344429ffff4c52989a83ec5ff2c68',

    // API基础URL
    apiBaseUrl: 'https://restapi.amap.com/v3',

    // 请求超时时间（毫秒）
    timeout: 10000,

    // 主要展示城市列表（首页默认显示，带adcode无需转换）
    mainCities: [
        { name: '北京', adcode: '110100' },
        { name: '上海', adcode: '310100' },
        { name: '广州', adcode: '440100' },
        { name: '深圳', adcode: '440300' },
        { name: '杭州', adcode: '330100' },
        { name: '成都', adcode: '510100' }
    ],

    // 常用城市列表（搜索用）
    quickCities: [
        { name: '北京', adcode: '110100' },
        { name: '上海', adcode: '310100' },
        { name: '广州', adcode: '440100' },
        { name: '深圳', adcode: '440300' },
        { name: '杭州', adcode: '330100' },
        { name: '成都', adcode: '510100' },
        { name: '武汉', adcode: '420100' },
        { name: '重庆', adcode: '500100' },
        { name: '西安', adcode: '610100' },
        { name: '南京', adcode: '320100' }
    ],

    // 天气图标映射
    weatherIcons: {
        '晴': '☀️',
        '多云': '⛅',
        '阴': '☁️',
        '小雨': '🌧️',
        '中雨': '🌧️',
        '大雨': '🌧️',
        '暴雨': '⛈️',
        '小雪': '❄️',
        '中雪': '❄️',
        '大雪': '❄️',
        '暴雪': '⛄',
        '雷阵雨': '⛈️',
        '雨夹雪': '🌨️',
        '阵雨': '🌧️',
        '雾': '🌫️',
        '霾': '🌫️',
        '沙尘暴': '🌪️'
    }
};
